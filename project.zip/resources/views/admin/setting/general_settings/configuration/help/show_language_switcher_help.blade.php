<div class="row">
    <div class="col-md-12">
        <div class="item-top p-4 text-center">
            <h1 class="p-2">{{ __('Show Language Switcher') }}</h1><br>
            <hr>
            <h3 class="p-2">{{__('If you enable this. The system will enable for show language switcher. By wearing it you will know how this setting works..')}}</h3>
            <br>
            <a class="btn btn-success" target="_blank"
               href="https://zaiscripe-doc.zainikthemes.com">{{ __('View the documentation') }}</a>
        </div>
    </div>
</div>
