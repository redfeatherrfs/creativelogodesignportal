@component('mail::message')

<div class="message">
    <p>{{ $request->message }}</p>
</div>

@endcomponent